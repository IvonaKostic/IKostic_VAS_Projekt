import time

from spade.agent import Agent
from spade.behaviour import FSMBehaviour, State
from spade.message import Message
import json
from asyncio import sleep

class Auto(Agent):
    def __init__(self, jid, password, nazivAuta, brSekDoSemafora):
        super().__init__(jid, password)
        self.nazivAuta = nazivAuta
        self.brSekDoSemafora = brSekDoSemafora

    class AutoPonasanje(FSMBehaviour):
        async def on_start(self):
            print(f"Pokrećem agenta: {self.agent.nazivAuta}")

        async def on_end(self):
            print(f"Zavrsavam agenta: {self.agent.nazivAuta}")
            await self.agent.stop()

    async def setup(self):
        fsm = self.AutoPonasanje()
        fsm.add_state(name="VoznjaDoSemafora", state=self.VoznjaDoSemafora(), initial=True)
        fsm.add_state(name="CekanjeNaZeleno", state=self.CekanjeNaZeleno())
        fsm.add_state(name="PresaoSemafor", state=self.PresaoSemafor())
        fsm.add_transition(source="VoznjaDoSemafora", dest="CekanjeNaZeleno")
        fsm.add_transition(source="CekanjeNaZeleno", dest="CekanjeNaZeleno")
        fsm.add_transition(source="CekanjeNaZeleno", dest="PresaoSemafor")
        self.add_behaviour(fsm)

    class VoznjaDoSemafora(State):
        async def run(self):
            for i in range(self.agent.brSekDoSemafora):
                print(
                    f"{self.agent.nazivAuta}: Vozim do semafora. Preostalo mi je još {self.agent.brSekDoSemafora - i} sekunde.")
                await sleep(1)
            print(f"{self.agent.nazivAuta}: Stigao sam do semafora.")
            self.set_next_state("CekanjeNaZeleno")

    class CekanjeNaZeleno(State):
        async def run(self):
            msg = Message(to="semafor@localhost", body=json.dumps({"svjetlo" :  "Koja je boja"}), metadata={"ontology": "semafor"})
            await self.send(msg)
            msg2 = await self.receive(timeout=3)
            if msg2 is None:
                self.set_next_state("CekanjeNaZeleno")
            else:
                sadrzaj = json.loads(msg2.body)
                if "svjetlo" in sadrzaj:
                    bojaSvjetla = sadrzaj["svjetlo"]
                    if bojaSvjetla == "zeleno":
                        self.set_next_state("PresaoSemafor")
                    else:
                        print(f"{self.agent.nazivAuta}: Trenutno je {bojaSvjetla}, cekam na semaforu!")
                        await sleep(1)
                        self.set_next_state("CekanjeNaZeleno")

    class PresaoSemafor(State):
        async def run(self):
            print(f"{self.agent.nazivAuta}: Presao sam semafor!!")