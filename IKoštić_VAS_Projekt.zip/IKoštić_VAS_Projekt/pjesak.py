import spade
import time
from semafor import Semafor
from random import randrange

from spade.agent import Agent
from spade.behaviour import FSMBehaviour, State
from spade.message import Message
import json
from asyncio import sleep

class Pjesak(Agent):
    def __init__(self, jid, password, nazivPjesaka,brSekDoSemafora):
        super().__init__(jid, password)
        self.nazivPjesaka = nazivPjesaka
        self.brSekDoSemafora = brSekDoSemafora


    class PjesakPonasanje(FSMBehaviour):
        async def on_start(self):
            print(f"Pokrećem agenta: {self.agent.nazivPjesaka}")

        async def on_end(self):
            print(f"Zavrsavam agenta: {self.agent.nazivPjesaka}")
            await self.agent.stop()

    async def setup(self):
        fsm = self.PjesakPonasanje()
        fsm.add_state(name="HodanjeDoSemafora", state=self.HodanjeDoSemafora(), initial=True)
        fsm.add_state(name="PritisniSemafor", state=self.PritisniSemafor())
        fsm.add_state(name="CekanjeNaZeleno", state=self.CekanjeNaZeleno())
        fsm.add_state(name="PrelazenjeCeste", state=self.PrelazenjeCeste())
        fsm.add_state(name="PresaoCestu", state=self.PresaoCestu())
        fsm.add_transition(source="HodanjeDoSemafora", dest="CekanjeNaZeleno")
        fsm.add_transition(source="PritisniSemafor", dest="CekanjeNaZeleno")
        fsm.add_transition(source="PritisniSemafor", dest="PrelazenjeCeste")
        fsm.add_transition(source="PrelazenjeCeste", dest="PresaoCestu")
        fsm.add_transition(source="CekanjeNaZeleno", dest="CekanjeNaZeleno")
        fsm.add_transition(source="CekanjeNaZeleno", dest="PritisniSemafor")
        fsm.add_transition(source="CekanjeNaZeleno", dest="PrelazenjeCeste")

        self.add_behaviour(fsm)

    class HodanjeDoSemafora(State):
        async def run(self):
            for i in range(self.agent.brSekDoSemafora):
                print(f"{self.agent.nazivPjesaka}: Hodam do semafora. Preostalo mi je još {self.agent.brSekDoSemafora - i} sekunde.")
                await sleep(1)
            print(f"{self.agent.nazivPjesaka}: Stigao sam do semafora.")
            self.set_next_state("CekanjeNaZeleno")

    class PritisniSemafor(State):
        async def run(self):
            print(f"{self.agent.nazivPjesaka}: Pritisnuo sam gumb na semaforu")
            msg = Message(to="semafor@localhost", body=json.dumps({"gumb": "Pritisnuti gumb"}), metadata={"ontology": "semafor"})
            await self.send(msg)
            await sleep(3)
            self.set_next_state("CekanjeNaZeleno")
            #msg2 = await self.receive(timeout=5)
            #if msg2 is None:
            #   self.set_next_state("CekanjeNaZeleno")
            #else:
            #    sadrzaj = json.loads(msg2.body)
            #    if "svjetlo" in sadrzaj:
            #        bojaSvjetla = sadrzaj["svjetlo"]
            #        if bojaSvjetla == "zeleno" or bojaSvjetla == "zuto": -> on tu pogleda koje je svjetlo
            #            print(f"{self.agent.nazivPjesaka}: Trenutno je {bojaSvjetla}, cekam na semaforu!")
            #            await sleep(2) -> zbog cekanja može više puta pritisnuti semafor
            #            self.set_next_state("CekanjeNaZeleno")
            #        else:
            #            self.set_next_state("PrelazenjeCeste")
            #    else:
            #        print(f"{self.agent.nazivPjesaka}: Nisam dobio poruku")
            #        self.set_next_state("CekanjeNaZeleno")

    class CekanjeNaZeleno(State):
        async def run(self):
            msg = Message(to="semafor@localhost", body=json.dumps({"svjetlo" :  "Koja je boja"}), metadata={"ontology": "semafor"})
            await self.send(msg)
            msg2 = await self.receive(timeout=3)
            if msg2 is None:
                await sleep(1)
                self.set_next_state("CekanjeNaZeleno")
            else:
                sadrzaj = json.loads(msg2.body)
                if "svjetlo" in sadrzaj:
                    bojaSvjetla = sadrzaj["svjetlo"]
                    if bojaSvjetla == "zeleno":
                        self.set_next_state("PritisniSemafor")
                    elif bojaSvjetla == "zuto":
                        print(f"{self.agent.nazivPjesaka}: Trenutno je {bojaSvjetla}, cekam na semaforu!")
                        await sleep(2)
                        self.set_next_state("CekanjeNaZeleno")
                    else:
                        self.set_next_state("PrelazenjeCeste")

    class PrelazenjeCeste(State):
        async def run(self):
            print(f"{self.agent.nazivPjesaka}: Prelazim cestu")
            await sleep(2)
            self.set_next_state("PresaoCestu")

    class PresaoCestu(State):
        async def run(self):
            print(f"{self.agent.nazivPjesaka}: Presao sam cestu!!")