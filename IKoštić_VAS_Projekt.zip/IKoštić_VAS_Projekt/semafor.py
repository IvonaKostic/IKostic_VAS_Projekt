import time
import spade
import threading
from asyncio import sleep
import json
from datetime import datetime
from spade.agent import Agent
from spade.behaviour import FSMBehaviour, State
from spade.message import Message
class Semafor(Agent):

    def __init__(self, jid, password, brSekTrajanjaCrvenog):
        super().__init__(jid, password)
        self.brSekTrajanjaCrvenog = brSekTrajanjaCrvenog

    class SemaforPonasanje(FSMBehaviour):
        async def on_start(self):
            print("Pokrećem semafor..")

        async def on_end(self):
            print("Završavam semafor..")
            await self.agent.stop()

    async def setup(self):
        fsm = self.SemaforPonasanje()
        fsm.add_state(name="Zeleno", state=self.Zeleno(), initial=True)
        fsm.add_state(name="Zuto", state=self.Zuto())
        fsm.add_state(name="Crveno", state=self.Crveno())
        fsm.add_state(name="CekanjeZeleno", state=self.CekanjeZeleno())
        fsm.add_state(name="CekanjeCrveno", state=self.CekanjeCrveno())
        fsm.add_state(name="CekanjeZuto", state=self.CekanjeZuto())
        fsm.add_transition(source="Zeleno", dest="CekanjeZeleno")
        fsm.add_transition(source="CekanjeZeleno", dest="CekanjeZeleno")
        fsm.add_transition(source="CekanjeZeleno", dest="Crveno")
        fsm.add_transition(source="Zuto", dest="CekanjeZuto")
        fsm.add_transition(source="CekanjeZuto", dest="Zeleno")
        fsm.add_transition(source="Crveno", dest="CekanjeCrveno")
        fsm.add_transition(source="CekanjeCrveno", dest="Zuto")
        self.add_behaviour(fsm)

    class Zeleno(State):
        async def run(self):
            print("Semafor: Upaljeno je zeleno")
            self.set_next_state("CekanjeZeleno")

    class Zuto(State):
        async def run(self):
            print("Semafor: Upaljeno je zuto")
            self.set_next_state("CekanjeZuto")

    class Crveno(State):
        async def run(self):
            print("Semafor: Upaljeno je crveno")
            self.set_next_state("CekanjeCrveno")

    class CekanjeZeleno(State):
        async def run(self):
            poruka = await self.receive(timeout = 20)
            if poruka is None:
                self.set_next_state("CekanjeZeleno")
            else:
                posiljatelj = str(poruka.sender)
                sadrzaj = json.loads(poruka.body)
                if "svjetlo" in sadrzaj:
                    #print("posiljatelj: ", posiljatelj)
                    #print("posiljatelj type: ", type(posiljatelj))
                    porukaPoslano = Message(to=posiljatelj, body=json.dumps({"svjetlo": "zeleno"}), metadata={"ontology": "semafor"})
                    await self.send(porukaPoslano)
                    self.set_next_state("CekanjeZeleno")
                elif "gumb" in sadrzaj:
                    vrijemePokretanje = datetime.now()
                    while True:
                        if (datetime.now() - vrijemePokretanje).total_seconds() > 2:
                            break
                        msg = await self.receive(timeout=1)
                        if msg is None:
                            continue
                        else:
                            sadrzaj = json.loads(msg.body)
                            if "svjetlo" in sadrzaj:
                                posiljatelj = str(msg.sender)
                                msgposlano = Message(to=posiljatelj, body=json.dumps({"svjetlo": "zeleno"}),
                                                 metadata={"ontology": "semafor"})
                                await self.send(msgposlano)
                    self.set_next_state("Crveno")
                else:
                    print("Semafor je dobio krivu poruku")
                    self.set_next_state("CekanjeZeleno")

    class CekanjeZuto(State):
        async def run(self):
            vrijemePokretanje = datetime.now()
            while True:
                if (datetime.now() - vrijemePokretanje).total_seconds() > 5:
                    break
                poruka = await self.receive(timeout = 1)
                if poruka is None:
                    continue
                else:
                    posiljatelj = str(poruka.sender)
                    porukaPoslano = Message(to=posiljatelj, body=json.dumps({"svjetlo" : "zuto"}), metadata={"ontology": "semafor"})
                    await self.send(porukaPoslano)
            self.set_next_state("Zeleno")

    class CekanjeCrveno(State):
        async def run(self):
            vrijemePokretanje = datetime.now()
            while True:
                if (datetime.now() - vrijemePokretanje).total_seconds() > self.agent.brSekTrajanjaCrvenog:
                    break
                poruka = await self.receive(timeout = 1)
                if poruka is None:
                    continue
                else:
                    posiljatelj = str(poruka.sender)
                    porukaPoslano = Message(to=posiljatelj, body=json.dumps({"svjetlo" : "crveno"}), metadata={"ontology": "semafor"})
                    await self.send(porukaPoslano)
            self.set_next_state("Zuto")

